return {
    tag_preview = require(... .. ".tag_preview"),
    task_preview = require(... .. ".task_preview"),
    window_switcher = require(... .. ".window_switcher"),
    tabbed_misc = require(... .. ".tabbed_misc"),
    app_launcher = require(... .. ".app_launcher"),
}
